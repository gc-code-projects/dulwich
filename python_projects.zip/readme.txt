turtle shapes you can choose (e.g., just use the command t.shape("steve")):

circle square arrow turtle steve squirtle ash 
redghost koopa peppa spaceship maro captain 
optimus autobots mario ninja mark googledino 
ironman cat flash thanos dog spiderman ghost
