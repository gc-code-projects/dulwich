import turtle
import marchturtle

'''
circle square arrow turtle steve squirtle ash 
redghost koopa peppa spaceship maro captain 
optimus autobots mario ninja mark googledino 
ironman cat flash thanos dog spiderman ghost
'''

t=turtle.Pen()
t.shape("arrow")

