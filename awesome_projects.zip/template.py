import turtle
import random
import marchturtle

'''
steve squirtle ash redghost koopa peppa spaceship 
maro captain optimus autobots mario ninja mark 
googledino ironman cat flash thanos dog spiderman ghost
'''

t=turtle.Pen()
